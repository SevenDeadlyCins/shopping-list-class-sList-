#include <QtCore/QCoreApplication>
#include "shoppinglist.h"
#include "ui_shoppinglist.h"
#include "Ingredient.h"
#include <vector>
#include <fstream>
#include <QFile>
#include <map>
#include <QTextStream>
#include<QFileDialog>
#include <QStandardPaths>
using namespace std;


QVector <QString> myList; // user's shopping list
QVector <QString> ingredientList; // list of ingredients

shoppingList::shoppingList(QWidget *parent) : QMainWindow(parent)
    , ui(new Ui::shoppingList)
{
    ui->setupUi(this);
}

shoppingList::~shoppingList()
{
    delete ui;
}

QString getResourcesPath() // get path based on system
{
#if defined(Q_OS_WIN)
    return QApplication::applicationDirPath() + "/"; // readFile path on Windows
#elif defined(Q_OS_OSX)
    return QApplication::applicationDirPath() + "/Users/Abady/Desktop/S/"; // readFile path on mac
#elif defined(Q_OS_LINUX)
    return QApplication::applicationDirPath() + "/../share/yourapplication/"; // readFile path on Linux
#else
    return QApplication::applicationDirPath() + "/";
#endif
}

//QString path = getResourcesPath(); // get the path based on system
//QString readFilePath = path + "readFile.txt"; // combine path and file name
//QString QStandardPaths::dataLocation(QStandardPaths::StandardLocation QString);

//QString pathy = AppDataLocation(QStandardPaths::StandardLocation txt);

    // function to read ingredients from file //
    void readFile()
    {
        QFile inputFile(qApp->applicationDirPath() + "/readFile.txt"); // read from readFile.txt
        cout<<qApp->applicationDirPath().toStdString() + "/readFile.txt";
        if (inputFile.open(QIODevice::ReadOnly)) // if file opened
        {
           QTextStream in(&inputFile);
           while (!in.atEnd())
           {
              QString line = in.readLine(); // getline
              ingredientList.push_back(line); // push_back line to ingredientList
               // cout<<line.toStdString() // to convert from QString to std::string
           }
           inputFile.close(); // close file when done reading
        }
    else
//            cout << inputFile.open(QIODevice::ReadOnly);
        cout << "\nnot opened;";
}

/*
void shoppingList::on_add1_clicked()
{
    myList.push_back(ui->label_1->text()); //
    QString str; // to store all strings in one variable
    for(int i = 0; i < myList.size(); i++){
        if (i>0)
            str += "\n";
        str += myList[i];
}
    ui->listView_2->setText(str);// print the one string variable whihch has all strings
//    ui->listView->append(ui->label_1->text());  // where ui->item_1 is a QLineEdit
  //  ui->listView->ensureCursorVisible();  // will scroll to bottom of list if necessary
}
*/


// add ingredient to ingredient list
void shoppingList::on_commandLinkButton_clicked()
{
    readFile(); // call
    for(int i = 0 ; i < ingredientList.size(); i++){
    ui->itemsList->addItem(ingredientList[i]);
    }

//    ui->itemsList->addItem(ui->lineEdit->text());
  //  ui->lineEdit->clear();
}

// add item from ingredient list to shopping list and display output
void shoppingList::on_itemsList_itemDoubleClicked(QListWidgetItem(*item))
{
    myList.push_back(item->text()); // push back the double clicked item to myList
     QString str; // to store all strings in one variable

     for(int i = 0; i < myList.size(); i++){
         if (i>0)
             str += "\n";
         str += myList[i];
 }
     ui->listView_2->setText(str);// print the one string variable whihch has all strings
}

// remove all items from shopoing list
void shoppingList::on_remove_1_clicked()
{
    myList.clear(); // erase all elements in vector
    ui->listView_2->clear(); // clear the listView_2
}


//-- menue bar -- //
void shoppingList::on_ageButton_clicked()
{
    ui->ShoppingList->setCurrentIndex(1);
}

void shoppingList::on_homeButton_clicked()
{
    ui->ShoppingList->setCurrentIndex(1);
}

void shoppingList::on_recipesButton_clicked()
{
    ui->ShoppingList->setCurrentIndex(2);
}

void shoppingList::on_sListButton_clicked()
{
    ui->ShoppingList->setCurrentIndex(3);
}

