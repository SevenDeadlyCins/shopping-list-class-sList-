#ifndef SHOPPINGLIST_H
#define SHOPPINGLIST_H

#include <QListWidget>
#include <iostream>
#include <vector>
//#include "Ingredient.h"
#include <QMainWindow>
#include <string>

QT_BEGIN_NAMESPACE
namespace Ui { class shoppingList; }
QT_END_NAMESPACE

class shoppingList : public QMainWindow
{
    Q_OBJECT

public:
    shoppingList(QWidget *parent = nullptr);
    ~shoppingList();

    void addIngredient(QString); // add ingredient to shopping list
    void removeIngredient(QString);
    QString getName(QString); // return name of ingredient
    void display(); // display all ingredient with the total price

private slots:
/*    void on_add1_clicked();

    void on_add2_clicked();

    void on_add3_clicked();

    void on_add4_clicked();

    void on_add5_clicked();

    void on_add6_clicked();

    void on_add7_clicked();

    void on_add8_clicked();
*/
    void on_itemsList_itemDoubleClicked(QListWidgetItem *item); // double clicking an item in ingredient list

    void on_remove_1_clicked(); // clear shopping list

    void on_ageButton_clicked(); // age verification button

    void on_homeButton_clicked(); // takes you to home page

    void on_recipesButton_clicked(); // takes you to recipes page

    void on_sListButton_clicked(); // takes you to shopping list page



    void on_commandLinkButton_clicked();

private:
    Ui::shoppingList *ui;
//    QVector <QString> list; // list of ingeredients

};


#endif
