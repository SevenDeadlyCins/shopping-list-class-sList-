/********************************************************************************
** Form generated from reading UI file 'shoppinglist.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SHOPPINGLIST_H
#define UI_SHOPPINGLIST_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCommandLinkButton>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListView>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_shoppingList
{
public:
    QAction *actionReciepes;
    QWidget *centralwidget;
    QStackedWidget *ShoppingList;
    QWidget *Age;
    QPushButton *ageButton;
    QTextBrowser *textBrowser_2;
    QWidget *home;
    QTextBrowser *textBrowser;
    QWidget *Recipes;
    QListView *reciList;
    QWidget *sList;
    QToolButton *remove_1;
    QLabel *label;
    QTextBrowser *listView_2;
    QListWidget *itemsList;
    QCommandLinkButton *commandLinkButton;
    QLabel *label_2;
    QPushButton *recipesButton;
    QPushButton *homeButton;
    QPushButton *sListButton;
    QPushButton *aboutButton;

    void setupUi(QMainWindow *shoppingList)
    {
        if (shoppingList->objectName().isEmpty())
            shoppingList->setObjectName(QString::fromUtf8("shoppingList"));
        shoppingList->resize(540, 399);
        shoppingList->setMinimumSize(QSize(540, 0));
        shoppingList->setMaximumSize(QSize(540, 16777215));
        actionReciepes = new QAction(shoppingList);
        actionReciepes->setObjectName(QString::fromUtf8("actionReciepes"));
        centralwidget = new QWidget(shoppingList);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        ShoppingList = new QStackedWidget(centralwidget);
        ShoppingList->setObjectName(QString::fromUtf8("ShoppingList"));
        ShoppingList->setGeometry(QRect(30, 30, 461, 351));
        Age = new QWidget();
        Age->setObjectName(QString::fromUtf8("Age"));
        ageButton = new QPushButton(Age);
        ageButton->setObjectName(QString::fromUtf8("ageButton"));
        ageButton->setGeometry(QRect(170, 250, 113, 32));
        textBrowser_2 = new QTextBrowser(Age);
        textBrowser_2->setObjectName(QString::fromUtf8("textBrowser_2"));
        textBrowser_2->setGeometry(QRect(80, 30, 291, 191));
        ShoppingList->addWidget(Age);
        home = new QWidget();
        home->setObjectName(QString::fromUtf8("home"));
        textBrowser = new QTextBrowser(home);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setGeometry(QRect(50, 90, 351, 161));
        ShoppingList->addWidget(home);
        Recipes = new QWidget();
        Recipes->setObjectName(QString::fromUtf8("Recipes"));
        reciList = new QListView(Recipes);
        reciList->setObjectName(QString::fromUtf8("reciList"));
        reciList->setGeometry(QRect(90, 70, 256, 192));
        ShoppingList->addWidget(Recipes);
        sList = new QWidget();
        sList->setObjectName(QString::fromUtf8("sList"));
        remove_1 = new QToolButton(sList);
        remove_1->setObjectName(QString::fromUtf8("remove_1"));
        remove_1->setGeometry(QRect(30, 270, 251, 21));
        label = new QLabel(sList);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(30, 60, 251, 41));
        listView_2 = new QTextBrowser(sList);
        listView_2->setObjectName(QString::fromUtf8("listView_2"));
        listView_2->setGeometry(QRect(30, 100, 251, 161));
        itemsList = new QListWidget(sList);
        itemsList->setObjectName(QString::fromUtf8("itemsList"));
        itemsList->setGeometry(QRect(310, 100, 141, 161));
        commandLinkButton = new QCommandLinkButton(sList);
        commandLinkButton->setObjectName(QString::fromUtf8("commandLinkButton"));
        commandLinkButton->setGeometry(QRect(70, 20, 351, 41));
        label_2 = new QLabel(sList);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(320, 70, 181, 41));
        ShoppingList->addWidget(sList);
        recipesButton = new QPushButton(centralwidget);
        recipesButton->setObjectName(QString::fromUtf8("recipesButton"));
        recipesButton->setGeometry(QRect(130, 0, 113, 32));
        homeButton = new QPushButton(centralwidget);
        homeButton->setObjectName(QString::fromUtf8("homeButton"));
        homeButton->setGeometry(QRect(30, 0, 113, 32));
        sListButton = new QPushButton(centralwidget);
        sListButton->setObjectName(QString::fromUtf8("sListButton"));
        sListButton->setGeometry(QRect(230, 0, 113, 32));
        aboutButton = new QPushButton(centralwidget);
        aboutButton->setObjectName(QString::fromUtf8("aboutButton"));
        aboutButton->setGeometry(QRect(330, 0, 113, 32));
        shoppingList->setCentralWidget(centralwidget);
        recipesButton->raise();
        homeButton->raise();
        sListButton->raise();
        aboutButton->raise();
        ShoppingList->raise();

        retranslateUi(shoppingList);

        ShoppingList->setCurrentIndex(3);


        QMetaObject::connectSlotsByName(shoppingList);
    } // setupUi

    void retranslateUi(QMainWindow *shoppingList)
    {
        shoppingList->setWindowTitle(QCoreApplication::translate("shoppingList", "shoppingList", nullptr));
        actionReciepes->setText(QCoreApplication::translate("shoppingList", "Reciepes", nullptr));
        ageButton->setText(QCoreApplication::translate("shoppingList", "Okay", nullptr));
        textBrowser_2->setHtml(QCoreApplication::translate("shoppingList", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'.SF NS Text'; font-size:18pt; color:#fc0107;\">This application is intended to be used by users over the age of 21. By using this application you are indicating that you are over 21.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'.SF NS Text'; font-size:18pt; color:#fc0107;\"><br /></p></body></html>", nullptr));
        textBrowser->setHtml(QCoreApplication::translate("shoppingList", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'.SF NS Text'; font-size:18pt; color:#0000ff;\">Welcome to Cocktail something!!</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'.SF NS Text'; font-size:18pt; color:#fc0107;\">Here you will find the best recipes ever. </span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'.SF NS Text'; font-size:18p"
                        "t; color:#0000ff;\"><br /></p></body></html>", nullptr));
#if QT_CONFIG(tooltip)
        reciList->setToolTip(QCoreApplication::translate("shoppingList", "<html><head/><body><p>first recipe</p><p>recipe2</p><p>recipe3</p><p>recipe4</p><p>recipe5</p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        remove_1->setText(QCoreApplication::translate("shoppingList", "Clear the list", nullptr));
        label->setText(QCoreApplication::translate("shoppingList", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'.SF NS Text'; font-size:13pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'.SF NS Text'; font-size:12pt; font-weight:600; color:#fc02ff;\">Your Shopping List</span></p></body></html>", nullptr));
        listView_2->setHtml(QCoreApplication::translate("shoppingList", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2';\"><br /></p></body></html>", nullptr));
        commandLinkButton->setText(QCoreApplication::translate("shoppingList", "Read Ingredient File readFile.txt", nullptr));
        label_2->setText(QCoreApplication::translate("shoppingList", "Double click to add to list:", nullptr));
        recipesButton->setText(QCoreApplication::translate("shoppingList", "Recipes", nullptr));
        homeButton->setText(QCoreApplication::translate("shoppingList", "Home", nullptr));
        sListButton->setText(QCoreApplication::translate("shoppingList", "Shopping List", nullptr));
        aboutButton->setText(QCoreApplication::translate("shoppingList", "About", nullptr));
    } // retranslateUi

};

namespace Ui {
    class shoppingList: public Ui_shoppingList {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SHOPPINGLIST_H
