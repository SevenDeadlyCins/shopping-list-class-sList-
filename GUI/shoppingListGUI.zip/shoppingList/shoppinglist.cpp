#include "shoppinglist.h"
#include "ui_shoppinglist.h"
//#include "Ingredient.h"
#include <vector>

QVector <QString> myList;

shoppingList::shoppingList(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::shoppingList)
{
    ui->setupUi(this);
}

shoppingList::~shoppingList()
{
    delete ui;
}

/*
void shoppingList::on_add1_clicked()
{
    myList.push_back(ui->label_1->text()); //
    QString str; // to store all strings in one variable
    for(int i = 0; i < myList.size(); i++){
        if (i>0)
            str += "\n";
        str += myList[i];
}
    ui->listView_2->setText(str);// print the one string variable whihch has all strings
//    ui->listView->append(ui->label_1->text());  // where ui->item_1 is a QLineEdit
  //  ui->listView->ensureCursorVisible();  // will scroll to bottom of list if necessary
}
*/

// add ingredient to ingredient list
void shoppingList::on_commandLinkButton_clicked()
{
    ui->itemsList->addItem(ui->lineEdit->text());
    ui->lineEdit->clear();
}

// add item from ingredient list to shopping list and display output
void shoppingList::on_itemsList_itemDoubleClicked(QListWidgetItem(*item))
{
    myList.push_back(item->text()); // push back the double clicked item to myList
     QString str; // to store all strings in one variable

     for(int i = 0; i < myList.size(); i++){
         if (i>0)
             str += "\n";
         str += myList[i];
 }
     ui->listView_2->setText(str);// print the one string variable whihch has all strings
}

// remove all items from shopoing list
void shoppingList::on_remove_1_clicked()
{
    myList.clear(); // erase all elements in vector
    ui->listView_2->clear(); // clear the listView_2
}


//-- menue bar -- //
void shoppingList::on_ageButton_clicked()
{
    ui->ShoppingList->setCurrentIndex(1);
}

void shoppingList::on_homeButton_clicked()
{
    ui->ShoppingList->setCurrentIndex(1);
}

void shoppingList::on_recipesButton_clicked()
{
    ui->ShoppingList->setCurrentIndex(2);
}

void shoppingList::on_sListButton_clicked()
{
    ui->ShoppingList->setCurrentIndex(3);
}

